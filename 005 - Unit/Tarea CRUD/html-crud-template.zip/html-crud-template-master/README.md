# HTML CRUD TEMPLATE

Basic HTML template for CRUD using Bootstrap 4 framework.